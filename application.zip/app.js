'use strict';

// --- Global Error Handler for Physical Devices ---
window.onerror = function(msg, url, line) {
    console.error('Error: ' + msg + '\nLine: ' + line);
    return false;
};

// --- Configuration & Constants ---
var API_KEYS = {
    learners: '6a4b3a8b-9eb7-4214-8bb5-3098dcd6f20e',
    school: '2efeaa9e-cc6d-4225-9d6d-9fe30b782e97'
};

var URLS = {
    learners: 'https://www.dictionaryapi.com/api/v3/references/learners/json',
    school: 'https://www.dictionaryapi.com/api/v3/references/sd4/json'
};

var AUDIO_BASE = 'https://media.merriam-webster.com/audio/prons/en/us/mp3';
var HISTORY_KEY = 'kai_dict_history';

// --- Icons (SVG Strings) ---
var ICONS = {
    sparkles: '<svg viewBox="0 0 24 24"><path d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z" /></svg>',
    history: '<svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zM12.75 6a.75.75 0 00-1.5 0v6c0 .414.336.75.75.75h4.5a.75.75 0 000-1.5h-3.75V6z" clip-rule="evenodd" /></svg>',
    backspace: '<svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2.515 10.674a1.875 1.875 0 000 2.652L8.89 19.7c.352.351.829.549 1.326.549H19.5a3 3 0 003-3V6.75a3 3 0 00-3-3h-9.284c-.497 0-.974.198-1.326.55l-6.375 6.374zM12.53 9.22a.75.75 0 10-1.06 1.06L13.19 12l-1.72 1.72a.75.75 0 101.06 1.06l1.72-1.72 1.72 1.72a.75.75 0 101.06-1.06L15.31 12l1.72-1.72a.75.75 0 10-1.06-1.06l-1.72 1.72-1.72-1.72z" clip-rule="evenodd" /></svg>',
    speaker: '<svg viewBox="0 0 24 24"><path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 001.5 12c0 .898.121 1.768.35 2.595.341 1.24 1.518 1.905 2.659 1.905h1.93l4.5 4.5c.945.945 2.561.276 2.561-1.06V4.06zM18.584 5.106a.75.75 0 011.06 0c3.808 3.807 3.808 9.98 0 13.788a.75.75 0 11-1.06-1.06 8.25 8.25 0 000-11.668.75.75 0 010-1.06z" /></svg>',
    switch: '<svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M15.97 2.47a.75.75 0 011.06 0l4.5 4.5a.75.75 0 010 1.06l-4.5 4.5a.75.75 0 11-1.06-1.06l3.22-3.22H7.5a.75.75 0 010-1.5h11.69l-3.22-3.22a.75.75 0 010-1.06zm-7.94 9a.75.75 0 010 1.06l-3.22 3.22H16.5a.75.75 0 010 1.5H4.81l3.22 3.22a.75.75 0 11-1.06 1.06l-4.5-4.5a.75.75 0 010-1.06l4.5-4.5a.75.75 0 011.06 0z" clip-rule="evenodd" /></svg>',
    folder: '<svg viewBox="0 0 24 24"><path d="M19.5 21a3 3 0 003-3v-4.5a3 3 0 00-3-3h-15a3 3 0 00-3 3V18a3 3 0 003 3h15zM1.5 10.146V6a3 3 0 013-3h5.379a2.25 2.25 0 011.59.659l2.122 2.121c.14.141.331.22.53.22H19.5a3 3 0 013 3v1.146A4.483 4.483 0 0019.5 9h-15a4.483 4.483 0 00-3 1.146z" /></svg>'
};

// --- Global State ---
var state = {
    view: 'home', // home, list, detail, history
    activeDict: 'learners', // learners, school
    query: '',
    results: [],
    history: [],
    suggestions: [],
    selectedEntry: null,
    navIndex: -1
};

// --- Initialization ---
window.addEventListener('load', function() {
    try {
        loadHistory();
        renderView();
        
        // Key listener for D-pad/Keyboard
        document.addEventListener('keydown', handleKeydown);
        
        // Global Click Listener (Event Delegation) for Mouse/Touch
        document.addEventListener('click', function(e) {
            // Find closest navigable item
            var target = e.target;
            while (target && target !== document) {
                if (target.classList.contains('nav-item')) {
                    handleInteraction(target);
                    return;
                }
                target = target.parentNode;
            }
        });
        
        // Hide loader after init
        var loader = document.getElementById('loader');
        if(loader) loader.classList.add('hidden');
        
        // Auto suggestions typing listener
        var typingTimer;
        var doneTypingInterval = 800;
        
        document.addEventListener('input', function(e) {
            if (e.target.tagName === 'INPUT') {
                state.query = e.target.value;
                clearTimeout(typingTimer);
                typingTimer = setTimeout(function() {
                    try {
                        if (state.view === 'home' && state.query.length >= 2) {
                            fetchSuggestions(state.query);
                        } else {
                            state.suggestions = [];
                            if (state.view === 'home') renderSuggestionsOnly();
                        }
                    } catch(err) {
                        console.error('Typing Handler Error: ' + err);
                    }
                }, doneTypingInterval);
            }
        });
    } catch(e) {
        alert('Init Error: ' + e.message);
    }
});

function loadHistory() {
    try {
        var saved = localStorage.getItem(HISTORY_KEY);
        if (saved) {
            state.history = JSON.parse(saved);
        }
    } catch (e) {
        console.error("History load error", e);
    }
}

function saveHistory() {
    try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(state.history));
    } catch(e) {
        console.error("History save error", e);
    }
}

// --- API ---
function ajax(url, callback, errorCallback) {
    var xhr = new XMLHttpRequest();
    // Enable systemXHR if available (needs privileged permission in manifest)
    try {
        xhr.open('GET', url, true);
    } catch(e) {
        // Fallback for standard web XHR
        console.log("XHR Open Error: " + e.message);
    }
    
    xhr.timeout = 15000; // 15 seconds timeout
    
    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 400) {
            try {
                var json = JSON.parse(xhr.responseText);
                callback(json);
            } catch(e) {
                if(errorCallback) errorCallback('Invalid JSON');
            }
        } else {
            if(errorCallback) errorCallback('Status: ' + xhr.status);
        }
    };
    
    xhr.onerror = function() {
        if(errorCallback) errorCallback('Network Error');
    };
    
    xhr.ontimeout = function() {
        if(errorCallback) errorCallback('Request Timed Out');
    };
    
    try {
        xhr.send();
    } catch(e) {
        if(errorCallback) errorCallback('Send Error: ' + e.message);
    }
}

function search(word) {
    if (!word || !word.trim()) return;
    
    var loader = document.getElementById('loader');
    if(loader) loader.classList.remove('hidden');
    
    var url = URLS[state.activeDict] + '/' + encodeURIComponent(word) + '?key=' + API_KEYS[state.activeDict];
    
    // Add to history
    var trimmed = word.trim();
    state.history = [trimmed].concat(state.history.filter(function(h){ return h.toLowerCase() !== trimmed.toLowerCase(); })).slice(0, 20);
    saveHistory();

    ajax(url, function(data) {
        if(loader) loader.classList.add('hidden');
        if (!data || (Array.isArray(data) && data.length === 0)) {
            alert('No results found for "' + word + '"');
            return;
        }
        state.results = data;
        state.view = 'list';
        renderView();
    }, function(err) {
        if(loader) loader.classList.add('hidden');
        alert('Connection Failed: ' + (err || 'Unknown'));
    });
}

function fetchSuggestions(word) {
    var url = URLS[state.activeDict] + '/' + encodeURIComponent(word) + '?key=' + API_KEYS[state.activeDict];
    ajax(url, function(data) {
        if (data && data.length > 0) {
            var suggs = [];
            for (var i=0; i<data.length; i++) {
                if (i > 3) break;
                var item = data[i];
                if (typeof item === 'string') {
                    suggs.push(item);
                } else if (item.hwi && item.hwi.hw) {
                    suggs.push(item.hwi.hw.replace(/\*/g, ''));
                }
            }
            state.suggestions = suggs;
        } else {
            state.suggestions = [];
        }
        // SAFE UPDATE: Only update suggestions
        if (state.view === 'home') renderSuggestionsOnly();
    }, function(err) {
        console.log("Suggestion error: " + err);
    });
}

// --- Audio ---
function getAudioUrl(audioFile) {
    if (!audioFile) return null;
    var subdir = '';
    if (audioFile.indexOf('bix') === 0) subdir = 'bix';
    else if (audioFile.indexOf('gg') === 0) subdir = 'gg';
    else if (/^\d/.test(audioFile)) subdir = 'number';
    else subdir = audioFile.charAt(0);
    return AUDIO_BASE + '/' + subdir + '/' + audioFile + '.mp3';
}

function playAudio(file) {
    var url = getAudioUrl(file);
    if (url) {
        var audio = new Audio(url);
        audio.play();
    }
}

// --- Interaction Logic (Replaces Inline OnClick) ---
function handleInteraction(el) {
    var action = el.getAttribute('data-action');
    if (!action) return;
    
    if (action === 'search') {
        var q = el.getAttribute('data-query');
        state.query = q;
        search(q);
    } else if (action === 'open') {
        var idx = parseInt(el.getAttribute('data-index'));
        openDetail(idx);
    } else if (action === 'play') {
        var file = el.getAttribute('data-file');
        playAudio(file);
    }
}

function openDetail(index) {
    state.selectedEntry = state.results[index];
    state.view = 'detail';
    renderView();
}

// --- Navigation Logic ---
function scrollFocusedIntoView(el) {
    var container = document.getElementById('view-container');
    if (!el || !container) return;

    var containerHeight = container.clientHeight;
    var elTop = el.offsetTop;
    var elHeight = el.offsetHeight;

    container.scrollTop = elTop - (containerHeight / 2) + (elHeight / 2);
}

function handleKeydown(e) {
    var focusable = Array.prototype.slice.call(document.querySelectorAll('.nav-item'));
    focusable = focusable.filter(function(el) { return el.offsetParent !== null; });
    
    var active = document.activeElement;
    var index = focusable.indexOf(active);

    switch(e.key) {
        case 'ArrowDown':
            e.preventDefault();
            if (focusable.length > 0) {
                var next = (index + 1) % focusable.length;
                focusable[next].focus();
                scrollFocusedIntoView(focusable[next]);
            }
            break;
        
        case 'ArrowUp':
            e.preventDefault();
            if (focusable.length > 0) {
                var prev = index <= 0 ? focusable.length - 1 : index - 1;
                focusable[prev].focus();
                scrollFocusedIntoView(focusable[prev]);
            }
            break;
            
        case 'Enter':
        case 'NumpadEnter':
            if (active.tagName === 'INPUT') {
                e.preventDefault();
                var val = active.value;
                state.query = val;
                search(val);
            } else if (index !== -1) {
                // Execute interaction based on data attributes
                // This bypasses inline onclick restrictions
                handleInteraction(active);
            }
            break;

        case 'SoftLeft':
        case 'F1':
            handleSoftKey('left');
            break;

        case 'SoftRight':
        case 'F2':
            handleSoftKey('right');
            break;

        case 'Backspace':
            if (active.tagName !== 'INPUT') {
                e.preventDefault();
                handleBackspace(active);
            }
            break;
            
        case 'ArrowLeft':
            if (state.view === 'home' && active.tagName === 'INPUT') {
                state.activeDict = state.activeDict === 'learners' ? 'school' : 'learners';
                renderHome();
            }
            break;

        case 'ArrowRight':
            if (state.view === 'home' && active.tagName === 'INPUT') {
                state.activeDict = state.activeDict === 'learners' ? 'school' : 'learners';
                renderHome();
            }
            break;
    }
}

function handleSoftKey(key) {
    if (state.view === 'home') {
        if (key === 'left') {
            state.view = 'history';
            renderView();
        } else if (key === 'right') {
            state.activeDict = state.activeDict === 'learners' ? 'school' : 'learners';
            renderHome();
        }
    } else if (state.view === 'history') {
        if (key === 'left') {
            state.history = [];
            saveHistory();
            renderView();
        } else if (key === 'right') {
            state.view = 'home';
            renderView();
        }
    } else {
        // List or Detail
        if (key === 'left') {
            if (state.view === 'detail') {
                state.view = 'list';
            } else {
                state.view = 'home';
                state.results = [];
            }
            renderView();
        }
    }
}

function handleBackspace(el) {
    if (state.view === 'history') {
        var val = el.getAttribute('data-value');
        state.history = state.history.filter(function(h) { return h !== val; });
        saveHistory();
        renderHistory();
        setTimeout(function() {
             var first = document.querySelector('.nav-item');
             if(first) first.focus();
        }, 50);
    } else if (state.view !== 'home') {
        handleSoftKey('left');
    }
}

// --- Renderers ---

function renderView() {
    var container = document.getElementById('view-container');
    container.innerHTML = '';
    
    if (state.view === 'home') renderHome();
    else if (state.view === 'history') renderHistory();
    else if (state.view === 'list') renderList();
    else if (state.view === 'detail') renderDetail();

    updateSoftkeys();
}

function updateSoftkeys() {
    var left = document.getElementById('softkey-left');
    var center = document.getElementById('softkey-center');
    var right = document.getElementById('softkey-right');

    if (state.view === 'home') {
        left.innerText = 'History';
        center.innerText = 'Search';
        right.innerText = 'Switch';
    } else if (state.view === 'history') {
        left.innerText = state.history.length > 0 ? 'Clear All' : '';
        center.innerText = 'Select';
        right.innerText = 'Back';
    } else {
        left.innerText = 'Back';
        center.innerText = 'Select';
        right.innerText = '';
    }
}

function renderHome() {
    var container = document.getElementById('view-container');
    
    var html = '<div class="home-header">' +
        '<h1 style="color:#5D5CDE; font-size:20px; font-weight:bold;">Dictionary</h1>' +
        '<p style="color:#9CA3AF; font-size:12px;">Merriam-Webster</p></div>';

    html += '<div class="search-container">' +
        '<input type="text" class="search-input nav-item" id="home-input" placeholder="Type a word..." value="'+state.query+'">' +
        '</div>';
        
    html += '<div class="dict-toggle">' +
        '<span class="'+(state.activeDict==='learners'?'text-primary':'text-gray')+'">Learner\'s</span>' +
        '<span>'+ICONS.switch+'</span>' +
        '<span class="'+(state.activeDict==='school'?'text-primary':'text-gray')+'">School</span>' +
        '</div>';
        
    html += '<div id="suggestions-container"></div>';
    
    container.innerHTML = html;
    
    renderSuggestionsOnly();
    
    var input = document.getElementById('home-input');
    if(input) {
        input.focus();
        var val = state.query;
        input.value = '';
        input.value = val;
    }
}

function renderSuggestionsOnly() {
    var container = document.getElementById('suggestions-container');
    if (!container) return;

    var html = '';
    if (state.suggestions.length > 0) {
        html += '<div class="section-title">'+ICONS.sparkles+' Suggestions</div>';
        for (var i=0; i<state.suggestions.length; i++) {
            // Using data attributes instead of onclick
            html += '<div class="list-item nav-item" tabindex="0" data-action="search" data-query="'+state.suggestions[i]+'">' +
                '<span>'+state.suggestions[i]+'</span>' +
                '</div>';
        }
    }
    container.innerHTML = html;
}

function renderHistory() {
    var container = document.getElementById('view-container');
    var html = '<div class="section-title" style="background:#374151; color:white; font-size:14px;">' + 
        ICONS.history + ' History</div>';
        
    if (state.history.length === 0) {
        html += '<div style="padding:20px; text-align:center; color:gray;">' + ICONS.folder + '<br>No History</div>';
    } else {
        for (var i=0; i<state.history.length; i++) {
            // Using data attributes
            html += '<div class="list-item nav-item" tabindex="0" data-action="search" data-query="'+state.history[i]+'" data-value="'+state.history[i]+'">' +
                '<span>'+state.history[i]+'</span>' +
                '<span class="text-gray" style="font-size:10px">'+ICONS.backspace+'</span>' +
                '</div>';
        }
    }
    container.innerHTML = html;
    setTimeout(function(){ 
        var first = container.querySelector('.nav-item');
        if(first) first.focus();
    }, 100);
}

function renderList() {
    var container = document.getElementById('view-container');
    
    var html = '<div class="detail-header flex justify-between items-center">' +
        '<span style="font-weight:bold; text-transform:capitalize">"'+state.query+'"</span>' +
        '<span style="font-size:10px; background:black; padding:2px 4px;">'+state.activeDict+'</span>' +
        '</div>';
        
    if (state.results.length > 0 && typeof state.results[0] === 'string') {
        html += '<div style="padding:10px; color:#FFA500;">Did you mean?</div>';
        for (var i=0; i<state.results.length; i++) {
            html += '<div class="list-item nav-item" tabindex="0" data-action="search" data-query="'+state.results[i]+'">' +
                state.results[i] + '</div>';
        }
    } else if (state.results.length === 0) {
        html += '<div style="padding:20px; text-align:center;">No results found.</div>';
    } else {
        for (var i=0; i<state.results.length; i++) {
            var item = state.results[i];
            var hw = item.hwi && item.hwi.hw ? item.hwi.hw.replace(/\*/g, '·') : state.query;
            var fl = item.fl || '';
            
            // Using data attributes, removed inline onclick
            html += '<div class="list-item nav-item flex-col" tabindex="0" style="align-items:flex-start" data-action="open" data-index="'+i+'">' +
                '<div style="font-size:16px; font-weight:bold; color:#5D5CDE;">'+hw+'</div>' +
                '<div style="font-size:12px; font-style:italic; color:#9CA3AF;">'+fl+'</div>' +
                '</div>';
        }
    }
    
    container.innerHTML = html;
    setTimeout(function(){ 
        var first = container.querySelector('.nav-item');
        if(first) first.focus();
    }, 100);
}

function renderDetail() {
    var container = document.getElementById('view-container');
    var item = state.selectedEntry;
    if (!item) return;
    
    var hw = item.hwi && item.hwi.hw ? item.hwi.hw.replace(/\*/g, '·') : '';
    var fl = item.fl || '';
    var prs = item.hwi && item.hwi.prs && item.hwi.prs[0] ? item.hwi.prs[0].mw : '';
    var audio = item.hwi && item.hwi.prs && item.hwi.prs[0] && item.hwi.prs[0].sound ? item.hwi.prs[0].sound.audio : null;

    var html = '<div class="detail-header">' +
        '<div class="word-title">'+hw+'</div>' +
        '<div class="word-meta">'+fl + (prs ? ' /'+prs+'/' : '') +'</div>' +
        '</div>';
        
    html += '<div class="detail-content">';
    
    if (audio) {
        // Data attribute for audio
        html += '<div class="audio-btn nav-item" tabindex="0" data-action="play" data-file="'+audio+'">' +
            ICONS.speaker + ' Play Pronunciation</div>';
    }
    
    if (item.shortdef) {
        html += '<div style="font-size:11px; font-weight:bold; color:#9CA3AF; margin-bottom:5px; text-transform:uppercase;">Definitions</div>';
        for (var i=0; i<item.shortdef.length; i++) {
            html += '<div class="def-block nav-item" tabindex="0">' +
                '<span style="font-weight:bold; color:#5D5CDE; margin-right:5px;">'+(i+1)+'.</span>' +
                item.shortdef[i] + '</div>';
        }
    }
    
    html += '</div>';
    
    container.innerHTML = html;
    setTimeout(function(){ 
        var first = container.querySelector('.nav-item');
        if(first) first.focus();
    }, 100);
}
