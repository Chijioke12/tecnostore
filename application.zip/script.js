// Extracted from script tag 1
"use strict";

function readTokenFile(file) {
  return new Promise(function (resolve, reject) {
    if (!file) {
      reject(new Error('No file selected'));
      return;
    }
    if (file.type !== 'text/plain' && file.name.slice(-4) !== '.txt') {
      reject(new Error('Please select a .txt file'));
      return;
    }
    var reader = new FileReader();
    reader.onload = function (e) {
      var token = e.target.result.trim();
      if (!token || token.indexOf('ghp_') !== 0) {
        reject(new Error('Invalid GitHub token format'));
        return;
      }
      resolve(token);
    };
    reader.onerror = function () {
      reject(new Error('Failed to read file'));
    };
    reader.readAsText(file);
  });
}
var sites = [];
var currentView = 'github-setup';
var currentFocus = 0;
var viewStack = [];
var editingSiteId = null;
var contextMenu = null;
var isInContextMenu = false;
var confirmDialog = null;
var isInConfirmDialog = false;
var confirmDialogFocus = 0;
var isAuthenticated = false;
var isDemoMode = false;
var githubConfig = null;
var lastSyncTime = null;
var uploadedToken = null;
var rateLimitInfo = {
  remaining: 60,
  resetTime: Date.now() + 3600000,
  lastApiCall: 0
};
var GITHUB_API_BASE = 'https://api.github.com';
var DATA_FILE_NAME = 'sites-data.json';
var DEMO_SITES = [{
  id: 'demo1',
  title: 'GitHub',
  url: 'https://github.com',
  favicon: 'https://www.google.com/s2/favicons?domain=github.com'
}, {
  id: 'demo2',
  title: 'Stack Overflow',
  url: 'https://stackoverflow.com',
  favicon: 'https://www.google.com/s2/favicons?domain=stackoverflow.com'
}, {
  id: 'demo3',
  title: 'Mozilla Developer Network',
  url: 'https://developer.mozilla.org',
  favicon: 'https://www.google.com/s2/favicons?domain=developer.mozilla.org'
}];
function scrollToCenter(element) {
  if (!element) return;
  var container = document.getElementById('content');
  var containerHeight = container.clientHeight;
  var elementHeight = element.offsetHeight;
  var elementTop = element.offsetTop;
  var centerPosition = elementTop - containerHeight / 2 + elementHeight / 2;
  var targetScrollTop = Math.max(0, centerPosition);
  var startScrollTop = container.scrollTop;
  var distance = targetScrollTop - startScrollTop;
  var startTime = null;
  var duration = 300;
  function smoothScrollAnimation(currentTime) {
    if (startTime === null) startTime = currentTime;
    var timeElapsed = currentTime - startTime;
    var progress = Math.min(timeElapsed / duration, 1);
    var ease = 1 - Math.pow(1 - progress, 3);
    container.scrollTop = startScrollTop + distance * ease;
    if (progress < 1) {
      requestAnimationFrame(smoothScrollAnimation);
    }
  }
  requestAnimationFrame(smoothScrollAnimation);
  updateFocusIndicator(element);
}
function updateFocusIndicator(element) {
  var indicator = document.getElementById('focus-indicator');
  if (!indicator || !element) return;
  var container = document.getElementById('content');
  var elementRect = element.getBoundingClientRect();
  var containerRect = container.getBoundingClientRect();
  var top = elementRect.top - containerRect.top + container.scrollTop;
  indicator.style.top = top + 'px';
  indicator.style.height = element.offsetHeight + 'px';
  indicator.style.display = 'block';
}
function checkRateLimit() {
  var now = Date.now();
  if (now > rateLimitInfo.resetTime) {
    rateLimitInfo.remaining = 60;
    rateLimitInfo.resetTime = now + 3600000;
  }
  return rateLimitInfo.remaining > 0;
}
function updateRateLimitInfo(response) {
  if (response && response.headers) {
    var remaining = response.headers.get('X-RateLimit-Remaining');
    var reset = response.headers.get('X-RateLimit-Reset');
    if (remaining) rateLimitInfo.remaining = parseInt(remaining);
    if (reset) rateLimitInfo.resetTime = parseInt(reset) * 1000;
  }
  updateRateLimitDisplay();
}
function updateRateLimitDisplay() {
  var rateLimitEl = document.getElementById('rate-limit-info');
  var apiCallsEl = document.getElementById('api-calls');
  if (rateLimitEl && isAuthenticated && !isDemoMode) {
    var resetTime = new Date(rateLimitInfo.resetTime);
    var timeStr = resetTime.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
    rateLimitEl.textContent = 'API: ' + rateLimitInfo.remaining + '/60 (resets ' + timeStr + ')';
  }
  if (apiCallsEl) {
    apiCallsEl.textContent = 60 - rateLimitInfo.remaining + '/60';
  }
}
var makeGitHubRequest = function (url, options) {
  options = options === void 0 ? {} : options;
  return new Promise(function (resolve, reject) {
    if (isDemoMode) {
      return reject(new Error('Demo mode - no API access'));
    }
    if (!checkRateLimit()) {
      var resetTime = new Date(rateLimitInfo.resetTime);
      return reject(new Error('Rate limit exceeded. Resets at ' + resetTime.toLocaleTimeString()));
    }
    var timeSinceLastCall = Date.now() - rateLimitInfo.lastApiCall;
    var delayPromise;
    if (timeSinceLastCall < 1000) {
      delayPromise = new Promise(function (resolveDelay) {
        setTimeout(resolveDelay, 1000 - timeSinceLastCall);
      });
    } else {
      delayPromise = Promise.resolve();
    }
    delayPromise.then(function () {
      rateLimitInfo.lastApiCall = Date.now();
      return fetch(url, options);
    }).then(function (response) {
      updateRateLimitInfo(response);
      resolve(response);
    }).catch(reject);
  });
};
document.getElementById('token-file').addEventListener('change', function (e) {
  var file = e.target.files[0];
  if (file) {
    readTokenFile(file).then(function (token) {
      uploadedToken = token;
      document.getElementById('token-upload').textContent = '✓ Token loaded (' + file.name + ')';
      clearMessages('setup-message-container');
    }).catch(function (error) {
      showMessage('setup-message-container', error.message, 'error');
      uploadedToken = null;
    });
  }
});
document.getElementById('update-token-file').addEventListener('change', function (e) {
  var file = e.target.files[0];
  if (file) {
    readTokenFile(file).then(function (token) {
      uploadedToken = token;
      document.getElementById('update-token-upload').textContent = '✓ Token loaded (' + file.name + ')';
      clearMessages('github-settings-message-container');
    }).catch(function (error) {
      showMessage('github-settings-message-container', error.message, 'error');
      uploadedToken = null;
    });
  }
});
function checkAuthentication() {
  var storedConfig = localStorage.getItem('github-config');
  var demoMode = localStorage.getItem('demo-mode');
  if (demoMode === 'true') {
    isDemoMode = true;
    sites = DEMO_SITES.slice();
    showView('main-menu', false);
    updateAuthStatus();
    updateSitesCount();
    renderSites();
    return;
  }
  if (storedConfig) {
    try {
      githubConfig = JSON.parse(storedConfig);
      validateGitHubConnection();
    } catch (e) {
      localStorage.removeItem('github-config');
      showSetupView();
    }
  } else {
    showSetupView();
  }
}
function showSetupView() {
  isAuthenticated = false;
  isDemoMode = false;
  currentView = 'github-setup';
  currentFocus = 0;
  updateHeaderTitle();
  updateFocus();
}
function enterDemoMode() {
  isDemoMode = true;
  isAuthenticated = false;
  sites = DEMO_SITES.slice();
  localStorage.setItem('demo-mode', 'true');
  localStorage.removeItem('github-config');
  showView('main-menu', false);
  updateAuthStatus();
  updateSitesCount();
  renderSites();
  showMessage('message-container', 'Demo mode active - no sync available', 'success', 3000);
}
var validateGitHubConnection = function () {
  if (!githubConfig) return Promise.resolve(false);
  return makeGitHubRequest(GITHUB_API_BASE + '/repos/' + githubConfig.repo, {
    headers: {
      'Authorization': 'token ' + githubConfig.token,
      'Accept': 'application/vnd.github.v3+json'
    }
  }).then(function (response) {
    if (response.ok) {
      isAuthenticated = true;
      isDemoMode = false;
      return loadSitesFromGitHub().then(function () {
        showView('main-menu', false);
        updateAuthStatus();
        return true;
      });
    } else {
      throw new Error('Repository access denied');
    }
  }).catch(function (error) {
    console.error('GitHub connection failed:', error);
    if (error.message.indexOf('Rate limit') !== -1) {
      updateSyncStatus(error.message, 'ratelimited');
    }
    showSetupView();
    return false;
  });
};
var connectToGitHub = function () {
  var repo = document.getElementById('github-repo').value.trim();
  clearMessages('setup-message-container');
  if (!uploadedToken || !repo) {
    showMessage('setup-message-container', 'Token file and repository are required', 'error');
    return;
  }
  if (repo.indexOf('/') === -1) {
    showMessage('setup-message-container', 'Repository format: username/repo-name', 'error');
    return;
  }
  makeGitHubRequest(GITHUB_API_BASE + '/repos/' + repo, {
    headers: {
      'Authorization': 'token ' + uploadedToken,
      'Accept': 'application/vnd.github.v3+json'
    }
  }).then(function (response) {
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error('Repository not found');
      } else if (response.status === 401) {
        throw new Error('Invalid token or access denied');
      } else {
        throw new Error('Connection failed');
      }
    }
    githubConfig = {
      token: uploadedToken,
      repo: repo
    };
    localStorage.setItem('github-config', JSON.stringify(githubConfig));
    localStorage.removeItem('demo-mode');
    isAuthenticated = true;
    isDemoMode = false;
    return loadSitesFromGitHub();
  }).then(function () {
    showMessage('setup-message-container', 'Connected successfully!', 'success', 2000);
    setTimeout(function () {
      showView('main-menu', false);
      updateAuthStatus();
    }, 2000);
  }).catch(function (error) {
    showMessage('setup-message-container', error.message, 'error');
    if (error.message.indexOf('Rate limit') !== -1) {
      updateSyncStatus(error.message, 'ratelimited');
    }
  });
};
var loadSitesFromGitHub = function () {
  if (!isAuthenticated || !githubConfig || isDemoMode) return Promise.resolve();
  updateSyncStatus('Loading sites...', 'syncing');
  return makeGitHubRequest(GITHUB_API_BASE + '/repos/' + githubConfig.repo + '/contents/' + DATA_FILE_NAME, {
    headers: {
      'Authorization': 'token ' + githubConfig.token,
      'Accept': 'application/vnd.github.v3+json'
    }
  }).then(function (response) {
    if (response.ok) {
      return response.json().then(function (data) {
        var content = atob(data.content);
        sites = JSON.parse(content);
        lastSyncTime = new Date();
        updateSyncStatus('Sites loaded', 'success', 2000);
      });
    } else if (response.status === 404) {
      sites = [];
      lastSyncTime = new Date();
      updateSyncStatus('No data file found, starting fresh', 'success', 2000);
    } else {
      throw new Error('Failed to load data');
    }
  }).then(function () {
    updateSitesCount();
    renderSites();
  }).catch(function (error) {
    console.error('Load from GitHub failed:', error);
    if (error.message.indexOf('Rate limit') !== -1) {
      updateSyncStatus(error.message, 'ratelimited', 5000);
    } else {
      updateSyncStatus('Failed to load sites', 'error', 3000);
    }
    sites = JSON.parse(localStorage.getItem('sites') || '[]');
    updateSitesCount();
    renderSites();
  });
};
var saveSitesToGitHub = function () {
  if (!isAuthenticated || !githubConfig || isDemoMode) {
    localStorage.setItem('sites', JSON.stringify(sites));
    if (isDemoMode) {
      showMessage('message-container', 'Changes saved locally (demo mode)', 'success', 2000);
    }
    return Promise.resolve();
  }
  updateSyncStatus('Syncing...', 'syncing');
  var getShaPromise = makeGitHubRequest(GITHUB_API_BASE + '/repos/' + githubConfig.repo + '/contents/' + DATA_FILE_NAME, {
    headers: {
      'Authorization': 'token ' + githubConfig.token,
      'Accept': 'application/vnd.github.v3+json'
    }
  }).then(function (currentFile) {
    if (currentFile.ok) {
      return currentFile.json().then(function (data) {
        return data.sha;
      });
    }
    return null;
  }).catch(function (e) {
    return null;
  });
  return getShaPromise.then(function (sha) {
    var content = btoa(JSON.stringify(sites, null, 2));
    var payload = {
      message: 'Update sites data - ' + new Date().toISOString(),
      content: content
    };
    if (sha) {
      payload.sha = sha;
    }
    return makeGitHubRequest(GITHUB_API_BASE + '/repos/' + githubConfig.repo + '/contents/' + DATA_FILE_NAME, {
      method: 'PUT',
      headers: {
        'Authorization': 'token ' + githubConfig.token,
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
  }).then(function (response) {
    if (response.ok) {
      lastSyncTime = new Date();
      updateSyncStatus('Synced successfully', 'success', 2000);
      localStorage.setItem('sites', JSON.stringify(sites));
    } else {
      throw new Error('Failed to save to GitHub');
    }
  }).catch(function (error) {
    console.error('Save to GitHub failed:', error);
    if (error.message.indexOf('Rate limit') !== -1) {
      updateSyncStatus(error.message, 'ratelimited', 5000);
    } else {
      updateSyncStatus('Sync failed, saved locally', 'error', 3000);
    }
    localStorage.setItem('sites', JSON.stringify(sites));
  });
};
function updateSyncStatus(message, type, duration) {
  duration = duration === void 0 ? 0 : duration;
  var mainStatus = document.getElementById('main-sync-status');
  if (mainStatus) {
    mainStatus.textContent = message;
    mainStatus.className = 'sync-status ' + type;
    if (duration > 0) {
      setTimeout(function () {
        mainStatus.textContent = '';
        mainStatus.className = 'sync-status';
      }, duration);
    }
  }
}
function updateAuthStatus() {
  var statusElements = document.querySelectorAll('.auth-status, #auth-status-display, #github-settings-status');
  Array.prototype.slice.call(statusElements).forEach(function (el) {
    if (isDemoMode) {
      el.textContent = 'Demo Mode Active';
      el.className = el.className.indexOf('auth-status') !== -1 ? 'auth-status demo' : 'auth-status demo';
    } else if (isAuthenticated && githubConfig) {
      el.textContent = 'Connected: ' + githubConfig.repo;
      el.className = el.className.indexOf('auth-status') !== -1 ? 'auth-status authenticated' : 'auth-status authenticated';
    } else {
      el.textContent = 'Not Connected to GitHub';
      el.className = el.className.indexOf('auth-status') !== -1 ? 'auth-status unauthenticated' : 'auth-status unauthenticated';
    }
  });
  var lastSyncEl = document.getElementById('last-sync');
  if (lastSyncEl) {
    if (isDemoMode) {
      lastSyncEl.textContent = 'Demo Mode';
    } else if (lastSyncTime) {
      var timeStr = lastSyncTime.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      });
      lastSyncEl.textContent = timeStr;
    } else {
      lastSyncEl.textContent = 'Never';
    }
  }
  updateRateLimitDisplay();
}
function showCustomDialog(message, onConfirm, onCancel) {
  if (confirmDialog) {
    document.body.removeChild(confirmDialog);
  }
  confirmDialog = document.createElement('div');
  confirmDialog.className = 'confirm-dialog';
  confirmDialog.innerHTML = '<div class="dialog-content">' + '<div class="dialog-message">' + message + '</div>' + '<div class="dialog-buttons">' + '<button class="dialog-button confirm focused">Yes</button>' + '<button class="dialog-button">No</button>' + '</div>' + '</div>';
  document.body.appendChild(confirmDialog);
  isInConfirmDialog = true;
  confirmDialogFocus = 0;
  confirmDialog.onConfirm = onConfirm;
  confirmDialog.onCancel = onCancel;
  updateConfirmFocus();
}
function signOut() {
  showCustomDialog('Sign out? Choose new connection method:', function () {
    localStorage.removeItem('github-config');
    localStorage.removeItem('sites');
    localStorage.removeItem('demo-mode');
    githubConfig = null;
    isAuthenticated = false;
    isDemoMode = false;
    sites = [];
    lastSyncTime = null;
    uploadedToken = null;
    document.getElementById('token-file').value = '';
    document.getElementById('update-token-file').value = '';
    document.getElementById('token-upload').textContent = 'Select token.txt file';
    document.getElementById('update-token-upload').textContent = 'Select token.txt file';
    document.getElementById('github-repo').value = '';
    showSetupView();
    updateAuthStatus();
    updateSitesCount();
  });
}
function normalizeUrl(input) {
  var url = input.trim();
  if (!url) return null;
  if (!url.match(/^https?:\/\//)) {
    url = 'https://' + url;
  }
  try {
    var urlObj = new URL(url);
    return urlObj.href;
  } catch (e) {
    return null;
  }
}
function validateUrl(input) {
  var normalized = normalizeUrl(input);
  if (!normalized) {
    return {
      valid: false,
      error: 'Invalid URL format'
    };
  }
  try {
    var urlObj = new URL(normalized);
    if (['http:', 'https:'].indexOf(urlObj.protocol) === -1) {
      return {
        valid: false,
        error: 'Only HTTP/HTTPS allowed'
      };
    }
    return {
      valid: true,
      url: normalized
    };
  } catch (e) {
    return {
      valid: false,
      error: 'Invalid URL'
    };
  }
}
function showMessage(containerId, message, type, duration) {
  type = type === void 0 ? 'error' : type;
  duration = duration === void 0 ? 3000 : duration;
  var container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '<div class="message ' + type + '">' + message + '</div>';
  if (duration > 0) {
    setTimeout(function () {
      container.innerHTML = '';
    }, duration);
  }
}
function clearMessages(containerId) {
  var container = document.getElementById(containerId);
  if (container) {
    container.innerHTML = '';
  }
}
function updateConfirmFocus() {
  if (!confirmDialog) return;
  var buttons = confirmDialog.querySelectorAll('.dialog-button');
  Array.prototype.slice.call(buttons).forEach(function (btn) {
    return btn.classList.remove('focused');
  });
  if (buttons[confirmDialogFocus]) {
    buttons[confirmDialogFocus].classList.add('focused');
  }
}
function handleConfirmDialog(action) {
  if (!confirmDialog) return;
  var callback = action === 'confirm' ? confirmDialog.onConfirm : confirmDialog.onCancel;
  document.body.removeChild(confirmDialog);
  confirmDialog = null;
  isInConfirmDialog = false;
  confirmDialogFocus = 0;
  if (callback) callback();
  updateFocus();
}
function getFocusableElements() {
  if (isInContextMenu && contextMenu) {
    return contextMenu.querySelectorAll('.context-item');
  }
  var view = document.getElementById(currentView);
  return view.querySelectorAll('.menu-item, .list-item, .site-item, .form-button, .form-input, .settings-item, .file-upload');
}
function updateFocus() {
  if (isInConfirmDialog) return;
  var focusableElements = getFocusableElements();
  Array.prototype.slice.call(document.querySelectorAll('.focused')).forEach(function (el) {
    el.classList.remove('focused');
  });
  if (focusableElements.length === 0) {
    document.getElementById('focus-indicator').style.display = 'none';
    return;
  }
  currentFocus = Math.max(0, Math.min(currentFocus, focusableElements.length - 1));
  var focusedElement = focusableElements[currentFocus];
  focusedElement.classList.add('focused');
  if (focusedElement.classList.contains('file-upload')) {
    focusedElement.querySelector('input').blur();
  } else if (focusedElement.tagName === 'INPUT' && !focusedElement.matches(':focus')) {
    focusedElement.focus();
  }
  scrollToCenter(focusedElement);
  updateSoftKeys();
}
function updateSoftKeys() {
  var softLeft = document.getElementById('softleft');
  var softRight = document.getElementById('softright');
  if (isInContextMenu) {
    softLeft.textContent = 'Select';
    softRight.textContent = 'Back';
    return;
  }
  switch (currentView) {
    case 'github-setup':
      softLeft.textContent = 'Connect';
      softRight.textContent = 'Exit';
      break;
    case 'main-menu':
      softLeft.textContent = 'Select';
      softRight.textContent = 'Exit';
      break;
    case 'all-sites':
      softLeft.textContent = sites.length > 0 ? 'Options' : 'Add';
      softRight.textContent = 'Back';
      break;
    case 'add-site':
    case 'edit-site':
      softLeft.textContent = 'Save';
      softRight.textContent = 'Cancel';
      break;
    case 'search-sites':
      var searchResults = document.getElementById('search-results').children.length;
      if (searchResults > 0 && currentFocus > 0) {
        softLeft.textContent = 'Options';
      } else {
        softLeft.textContent = 'Search';
      }
      softRight.textContent = 'Back';
      break;
    case 'settings':
    case 'github-settings':
      softLeft.textContent = 'Select';
      softRight.textContent = 'Back';
      break;
    default:
      softLeft.textContent = 'Select';
      softRight.textContent = 'Back';
  }
}
function moveFocus(direction) {
  if (isInConfirmDialog) {
    if (direction === 'left' || direction === 'right') {
      confirmDialogFocus = confirmDialogFocus === 0 ? 1 : 0;
      updateConfirmFocus();
    }
    return;
  }
  var focusableElements = getFocusableElements();
  if (focusableElements.length === 0) return;
  if (direction === 'up') {
    currentFocus = currentFocus > 0 ? currentFocus - 1 : focusableElements.length - 1;
  } else if (direction === 'down') {
    currentFocus = currentFocus < focusableElements.length - 1 ? currentFocus + 1 : 0;
  }
  updateFocus();
}
function fastScroll(direction) {
  var focusableElements = getFocusableElements();
  if (focusableElements.length === 0) return;
  var jumpSize = Math.max(3, Math.floor(focusableElements.length / 5));
  if (direction === 'left') {
    currentFocus = Math.max(0, currentFocus - jumpSize);
  } else if (direction === 'right') {
    currentFocus = Math.min(focusableElements.length - 1, currentFocus + jumpSize);
  }
  updateFocus();
}
function showView(viewId, addToStack) {
  addToStack = addToStack === void 0 ? true : addToStack;
  if (addToStack && currentView !== viewId) {
    viewStack.push({
      view: currentView,
      focus: currentFocus
    });
  }
  Array.prototype.slice.call(document.querySelectorAll('.view')).forEach(function (view) {
    return view.classList.add('hidden');
  });
  document.getElementById(viewId).classList.remove('hidden');
  currentView = viewId;
  currentFocus = 0;
  isInContextMenu = false;
  clearMessages(viewId + '-message-container');
  updateHeaderTitle();
  updateAuthStatus();
  updateFocus();
}
function goBack() {
  if (isInConfirmDialog) {
    handleConfirmDialog('cancel');
    return;
  }
  if (isInContextMenu && contextMenu) {
    document.body.removeChild(contextMenu);
    contextMenu = null;
    isInContextMenu = false;
    updateFocus();
    return;
  }
  if (viewStack.length > 0) {
    var prevState = viewStack.pop();
    Array.prototype.slice.call(document.querySelectorAll('.view')).forEach(function (view) {
      return view.classList.add('hidden');
    });
    document.getElementById(prevState.view).classList.remove('hidden');
    currentView = prevState.view;
    currentFocus = prevState.focus;
    isInContextMenu = false;
    updateHeaderTitle();
    updateAuthStatus();
    updateFocus();
  } else if (currentView !== 'main-menu' && (isAuthenticated || isDemoMode)) {
    showView('main-menu', false);
    viewStack = [];
  } else if (currentView !== 'github-setup' && !isAuthenticated && !isDemoMode) {
    showView('github-setup', false);
    viewStack = [];
  }
}
function updateHeaderTitle() {
  var titles = {
    'github-setup': 'GitHub Setup',
    'main-menu': 'Site Manager',
    'all-sites': 'All Sites',
    'add-site': 'Add Site',
    'search-sites': 'Search Sites',
    'settings': 'Settings',
    'github-settings': 'GitHub Settings',
    'edit-site': 'Edit Site'
  };
  document.getElementById('header-title').textContent = titles[currentView] || 'Site Manager';
}
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}
function updateSitesCount() {
  var totalSitesEl = document.getElementById('total-sites');
  if (totalSitesEl) {
    totalSitesEl.textContent = sites.length;
  }
}
var addSite = function (title, url) {
  return new Promise(function (resolve, reject) {
    var validation = validateUrl(url);
    if (!validation.valid) {
      return reject(new Error(validation.error));
    }
    if (!title.trim()) {
      return reject(new Error('Title is required'));
    }
    var existingSite = null;
    for (var i = 0; i < sites.length; i++) {
      if (sites[i].url === validation.url) {
        existingSite = sites[i];
        break;
      }
    }
    if (existingSite) {
      return reject(new Error('Site already exists'));
    }
    var site = {
      id: generateId(),
      title: title.trim(),
      url: validation.url,
      favicon: 'https://www.google.com/s2/favicons?domain=' + encodeURIComponent(new URL(validation.url).hostname)
    };
    sites.push(site);
    saveSitesToGitHub().then(function () {
      updateSitesCount();
      resolve(true);
    }).catch(reject);
  });
};
var updateSite = function (id, title, url) {
  return new Promise(function (resolve, reject) {
    var validation = validateUrl(url);
    if (!validation.valid) {
      return reject(new Error(validation.error));
    }
    if (!title.trim()) {
      return reject(new Error('Title is required'));
    }
    var siteIndex = -1;
    for (var i = 0; i < sites.length; i++) {
      if (sites[i].id === id) {
        siteIndex = i;
        break;
      }
    }
    if (siteIndex === -1) {
      return reject(new Error('Site not found'));
    }
    var existingSite = null;
    for (var j = 0; j < sites.length; j++) {
      if (sites[j].url === validation.url && sites[j].id !== id) {
        existingSite = sites[j];
        break;
      }
    }
    if (existingSite) {
      return reject(new Error('Site with this URL already exists'));
    }
    sites[siteIndex].title = title.trim();
    sites[siteIndex].url = validation.url;
    sites[siteIndex].favicon = 'https://www.google.com/s2/favicons?domain=' + encodeURIComponent(new URL(validation.url).hostname);
    saveSitesToGitHub().then(function () {
      updateSitesCount();
      resolve(true);
    }).catch(reject);
  });
};
function deleteSite(id) {
  var site = null;
  for (var i = 0; i < sites.length; i++) {
    if (sites[i].id === id) {
      site = sites[i];
      break;
    }
  }
  if (!site) return;
  showCustomDialog('Delete "' + site.title + '"?', function () {
    if (isDemoMode) {
      sites = sites.filter(function (site) {
        return site.id !== id;
      });
      updateSitesCount();
      renderSites();
      showMessage('message-container', 'Site deleted (demo mode)', 'success');
    } else {
      sites = sites.filter(function (site) {
        return site.id !== id;
      });
      saveSitesToGitHub().then(function () {
        updateSitesCount();
        renderSites();
        showMessage('message-container', 'Site deleted successfully', 'success');
      });
    }
  });
}
function openSite(id) {
  var site = null;
  for (var i = 0; i < sites.length; i++) {
    if (sites[i].id === id) {
      site = sites[i];
      break;
    }
  }
  if (site && site.url) {
    try {
      window.location.href = site.url;
    } catch (e) {
      showMessage('message-container', 'Failed to open site', 'error');
    }
  }
}
function renderSites(sitesToRender, containerId) {
  sitesToRender = sitesToRender === void 0 ? sites : sitesToRender;
  containerId = containerId === void 0 ? 'sites-list' : containerId;
  var container = document.getElementById(containerId);
  var noSites = document.getElementById(currentView === 'search-sites' ? 'no-results' : 'no-sites');
  if (!container) return;
  if (sitesToRender.length === 0) {
    container.innerHTML = '';
    if (noSites) {
      noSites.classList.remove('hidden');
    }
    return;
  }
  if (noSites) {
    noSites.classList.add('hidden');
  }
  container.innerHTML = sitesToRender.map(function (site) {
    return '<div class="site-item" data-site-id="' + site.id + '">' + '<img src="' + site.favicon + '" class="site-favicon" alt="" onerror="this.style.display=\'none\'">' + '<div class="site-info">' + '<div class="site-title">' + site.title + '</div>' + '<div class="site-url">' + site.url + '</div>' + '</div>' + '</div>';
  }).join('');
}
function renderSearchResults(query) {
  var results = sites.filter(function (site) {
    return site.title.toLowerCase().indexOf(query.toLowerCase()) !== -1 || site.url.toLowerCase().indexOf(query.toLowerCase()) !== -1;
  });
  renderSites(results, 'search-results');
}
function showContextMenu(siteId, event, isSearch) {
  isSearch = isSearch === void 0 ? false : isSearch;
  if (contextMenu) {
    document.body.removeChild(contextMenu);
  }
  contextMenu = document.createElement('div');
  contextMenu.className = 'context-menu';
  contextMenu.innerHTML = '<div class="context-item" data-action="open">Open Site</div>' + '<div class="context-item" data-action="edit">Edit Site</div>' + '<div class="context-item" data-action="delete">Delete Site</div>';
  contextMenu.style.left = '60px';
  contextMenu.style.top = '120px';
  contextMenu.dataset.siteId = siteId;
  contextMenu.dataset.isSearch = isSearch;
  document.body.appendChild(contextMenu);
  isInContextMenu = true;
  currentFocus = 0;
  updateFocus();
}
function handleContextAction(action, siteId, isSearch) {
  isSearch = isSearch === void 0 ? false : isSearch;
  if (action === 'open') {
    openSite(siteId);
  } else if (action === 'edit') {
    var site = null;
    for (var i = 0; i < sites.length; i++) {
      if (sites[i].id === siteId) {
        site = sites[i];
        break;
      }
    }
    if (site) {
      document.getElementById('edit-title').value = site.title;
      document.getElementById('edit-url').value = site.url;
      editingSiteId = siteId;
      if (contextMenu) {
        document.body.removeChild(contextMenu);
        contextMenu = null;
      }
      isInContextMenu = false;
      showView('edit-site');
    }
  } else if (action === 'delete') {
    if (contextMenu) {
      document.body.removeChild(contextMenu);
      contextMenu = null;
    }
    isInContextMenu = false;
    deleteSite(siteId);
    if (isSearch) {
      var query = document.getElementById('search-input').value.trim();
      if (query) {
        renderSearchResults(query);
      }
    }
  }
}
document.addEventListener('keydown', function (event) {
  var activeElement = document.activeElement;
  var isInputFocused = activeElement && activeElement.tagName === 'INPUT' && activeElement.type === 'text';
  var navigationKeys = ['SoftLeft', 'SoftRight', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];
  if (navigationKeys.indexOf(event.key) !== -1 || event.key === 'Enter') {
    if (['ArrowLeft', 'ArrowRight'].indexOf(event.key) !== -1 && isInputFocused && !isInConfirmDialog) {
      return;
    }
    event.preventDefault();
    if (isInConfirmDialog) {
      switch (event.key) {
        case 'SoftLeft':
        case 'Enter':
          handleConfirmDialog('confirm');
          break;
        case 'SoftRight':
          handleConfirmDialog('cancel');
          break;
        case 'ArrowLeft':
        case 'ArrowRight':
          moveFocus(event.key.replace('Arrow', '').toLowerCase());
          break;
      }
      return;
    }
    switch (event.key) {
      case 'SoftLeft':
        handleSoftLeft();
        break;
      case 'SoftRight':
        goBack();
        break;
      case 'Enter':
        handleEnter();
        break;
      case 'ArrowUp':
        moveFocus('up');
        break;
      case 'ArrowDown':
        moveFocus('down');
        break;
      case 'ArrowLeft':
        if (!isInContextMenu) fastScroll('left');
        break;
      case 'ArrowRight':
        if (!isInContextMenu) fastScroll('right');
        break;
    }
  }
});
function handleSoftLeft() {
  if (isInContextMenu) {
    handleEnter();
    return;
  }
  switch (currentView) {
    case 'github-setup':
      var focusedElement = getFocusableElements()[currentFocus];
      if (focusedElement && focusedElement.id === 'demo-mode') {
        enterDemoMode();
      } else {
        connectToGitHub();
      }
      break;
    case 'main-menu':
      handleEnter();
      break;
    case 'all-sites':
      if (sites.length === 0) {
        showView('add-site');
      } else {
        var focusedSite = document.querySelector('.site-item.focused');
        if (focusedSite) {
          showContextMenu(focusedSite.dataset.siteId);
        }
      }
      break;
    case 'add-site':
      saveSiteForm();
      break;
    case 'edit-site':
      updateSiteForm();
      break;
    case 'github-settings':
      handleEnter();
      break;
    case 'search-sites':
      var focusedSearchSite = document.querySelector('#search-results .site-item.focused');
      if (focusedSearchSite) {
        showContextMenu(focusedSearchSite.dataset.siteId, null, true);
      } else {
        var query = document.getElementById('search-input').value.trim();
        if (query) {
          renderSearchResults(query);
          if (document.getElementById('search-results').children.length > 0) {
            currentFocus = 1;
            updateFocus();
          }
        }
      }
      break;
    case 'settings':
      handleEnter();
      break;
  }
}
function handleEnter() {
  if (isInContextMenu && contextMenu) {
    var focusedContext = contextMenu.querySelector('.context-item.focused');
    if (focusedContext) {
      var isSearch = contextMenu.dataset.isSearch === 'true';
      handleContextAction(focusedContext.dataset.action, contextMenu.dataset.siteId, isSearch);
    }
    return;
  }
  var focusableElements = getFocusableElements();
  var focusedElement = focusableElements[currentFocus];
  if (!focusedElement) return;
  if (focusedElement.classList.contains('file-upload')) {
    var fileInput = focusedElement.querySelector('input[type="file"]');
    if (fileInput) {
      fileInput.click();
    }
  } else if (focusedElement.classList.contains('menu-item')) {
    var action = focusedElement.dataset.action;
    switch (action) {
      case 'all-sites':
        renderSites();
        showView('all-sites');
        break;
      case 'add-site':
        showView('add-site');
        break;
      case 'search-sites':
        showView('search-sites');
        break;
      case 'settings':
        showView('settings');
        break;
      case 'sync-now':
        if (!isDemoMode) {
          loadSitesFromGitHub();
        } else {
          showMessage('message-container', 'Sync not available in demo mode', 'error', 2000);
        }
        break;
    }
  } else if (focusedElement.classList.contains('site-item')) {
    openSite(focusedElement.dataset.siteId);
  } else if (focusedElement.classList.contains('form-button')) {
    var id = focusedElement.id;
    switch (id) {
      case 'connect-github':
        connectToGitHub();
        break;
      case 'demo-mode':
        enterDemoMode();
        break;
      case 'save-site':
        saveSiteForm();
        break;
      case 'cancel-add':
      case 'cancel-edit':
      case 'cancel-github-settings':
        goBack();
        break;
      case 'update-site':
        updateSiteForm();
        break;
      case 'update-github':
        updateGitHubSettings();
        break;
      case 'disconnect-github':
        signOut();
        break;
    }
  } else if (focusedElement.classList.contains('settings-item')) {
    var text = focusedElement.querySelector('span').textContent;
    if (text === 'Export Data') {
      var data = JSON.stringify(sites, null, 2);
      console.log('Site data:', data);
      showMessage('message-container', 'Data exported to console', 'success');
    } else if (text === 'GitHub Settings') {
      if (!isDemoMode) {
        if (githubConfig) {
          document.getElementById('update-github-repo').value = githubConfig.repo;
        }
        showView('github-settings');
      } else {
        showMessage('message-container', 'GitHub settings not available in demo mode', 'error', 2000);
      }
    } else if (text === 'Sign Out') {
      signOut();
    }
  }
}
var updateGitHubSettings = function () {
  var repo = document.getElementById('update-github-repo').value.trim();
  clearMessages('github-settings-message-container');
  if (!uploadedToken || !repo) {
    showMessage('github-settings-message-container', 'Token file and repository are required', 'error');
    return;
  }
  makeGitHubRequest(GITHUB_API_BASE + '/repos/' + repo, {
    headers: {
      'Authorization': 'token ' + uploadedToken,
      'Accept': 'application/vnd.github.v3+json'
    }
  }).then(function (response) {
    if (!response.ok) {
      throw new Error('Connection failed');
    }
    githubConfig = {
      token: uploadedToken,
      repo: repo
    };
    localStorage.setItem('github-config', JSON.stringify(githubConfig));
    localStorage.removeItem('demo-mode');
    isDemoMode = false;
    showMessage('github-settings-message-container', 'Settings updated successfully!', 'success', 2000);
    setTimeout(function () {
      return goBack();
    }, 2000);
  }).catch(function (error) {
    showMessage('github-settings-message-container', error.message, 'error');
    if (error.message.indexOf('Rate limit') !== -1) {
      updateSyncStatus(error.message, 'ratelimited');
    }
  });
};
var saveSiteForm = function () {
  var title = document.getElementById('site-title').value.trim();
  var url = document.getElementById('site-url').value.trim();
  document.getElementById('site-title').classList.remove('error');
  document.getElementById('site-url').classList.remove('error');
  clearMessages('add-message-container');
  addSite(title, url).then(function (success) {
    if (success) {
      document.getElementById('site-title').value = '';
      document.getElementById('site-url').value = '';
      renderSites();
      showMessage('add-message-container', 'Site added successfully!', 'success', 2000);
      setTimeout(function () {
        return goBack();
      }, 2000);
    }
  }).catch(function (error) {
    showMessage('add-message-container', error.message, 'error');
    if (error.message.indexOf('URL') !== -1 || error.message.indexOf('format') !== -1) {
      document.getElementById('site-url').classList.add('error');
    }
    if (error.message.indexOf('Title') !== -1) {
      document.getElementById('site-title').classList.add('error');
    }
  });
};
var updateSiteForm = function () {
  var title = document.getElementById('edit-title').value.trim();
  var url = document.getElementById('edit-url').value.trim();
  document.getElementById('edit-title').classList.remove('error');
  document.getElementById('edit-url').classList.remove('error');
  clearMessages('edit-message-container');
  updateSite(editingSiteId, title, url).then(function (success) {
    if (editingSiteId && success) {
      renderSites();
      editingSiteId = null;
      showMessage('edit-message-container', 'Site updated successfully!', 'success', 2000);
      setTimeout(function () {
        return goBack();
      }, 2000);
    }
  }).catch(function (error) {
    showMessage('edit-message-container', error.message, 'error');
    if (error.message.indexOf('URL') !== -1 || error.message.indexOf('format') !== -1) {
      document.getElementById('edit-url').classList.add('error');
    }
    if (error.message.indexOf('Title') !== -1) {
      document.getElementById('edit-title').classList.add('error');
    }
  });
};
document.getElementById('search-input').addEventListener('input', function () {
  var query = this.value.trim();
  clearMessages('search-message-container');
  if (query) {
    renderSearchResults(query);
  } else {
    document.getElementById('search-results').innerHTML = '';
    document.getElementById('no-results').classList.add('hidden');
  }
});
checkAuthentication();
updateSitesCount();

// Extracted from script tag 2
// KaiOS Spatial Navigation System - Added by HTML Editor
(function() {
    var spatialNavigationEnabled = false;
    var toggleKey = '0';
    
    function updateSpatialNavigation() {
        if (typeof navigator !== 'undefined' && 'spatialNavigationEnabled' in navigator) {
            navigator.spatialNavigationEnabled = spatialNavigationEnabled;
        }
        
        if (spatialNavigationEnabled) {
            document.body.classList.add('spatial-navigation-enabled');
            console.log('Spatial navigation enabled - Use arrow keys to navigate');
        } else {
            document.body.classList.remove('spatial-navigation-enabled');
            console.log('Spatial navigation disabled');
        }
        
        // Focus first focusable element when enabling
        if (spatialNavigationEnabled) {
            var firstFocusable = document.querySelector('.focusable');
            if (firstFocusable) {
                firstFocusable.focus();
            }
        }
    }

    function toggleSpatialNavigation() {
        spatialNavigationEnabled = !spatialNavigationEnabled;
        updateSpatialNavigation();
    }

    function focusElement(move) {
        var focusableElements = document.querySelectorAll('.focusable');
        if (focusableElements.length === 0) return;

        var currentIndex = -1;
        for (var i = 0; i < focusableElements.length; i++) {
            if (focusableElements[i] === document.activeElement) {
                currentIndex = i;
                break;
            }
        }

        var nextIndex = currentIndex + move;
        if (nextIndex >= focusableElements.length) {
            nextIndex = 0;
        } else if (nextIndex < 0) {
            nextIndex = focusableElements.length - 1;
        }

        var targetElement = focusableElements[nextIndex];
        targetElement.focus();
        
        // KaiOS compatible scroll
        var container = targetElement.closest('.content') || document.getElementById('content');
        if (container && targetElement) {
            var containerHeight = container.clientHeight;
            var elementHeight = targetElement.offsetHeight;
            var elementTop = targetElement.offsetTop;
            var centerPosition = elementTop - containerHeight / 2 + elementHeight / 2;
            container.scrollTop = Math.max(0, centerPosition);
        }
    }

    // Enhanced spatial navigation for arrow keys
    function handleSpatialNavigation(e) {
        if (!spatialNavigationEnabled) return;

        switch (e.key) {
            case 'ArrowDown':
            case 'Down':
                e.preventDefault();
                focusElement(1);
                break;
            case 'ArrowUp':
            case 'Up':
                e.preventDefault();
                focusElement(-1);
                break;
            case 'ArrowLeft':
            case 'Left':
                e.preventDefault();
                focusElement(-1);
                break;
            case 'ArrowRight':
            case 'Right':
                e.preventDefault();
                focusElement(1);
                break;
            case 'Enter':
                e.preventDefault();
                if (document.activeElement && typeof document.activeElement.click === 'function') {
                    document.activeElement.click();
                }
                break;
        }
    }

    // Keyboard event listeners
    document.addEventListener('keyup', function(e) {
        if (e.key === toggleKey) {
            e.preventDefault();
            toggleSpatialNavigation();
        }
    });

    document.addEventListener('keydown', handleSpatialNavigation);

    // Initialize on load
    document.addEventListener('DOMContentLoaded', function() {
        updateSpatialNavigation();
        console.log('Spatial navigation initialized. Press "' + toggleKey + '" to toggle navigation mode.');
    });

    // Initialize immediately if DOM is already loaded
    if (document.readyState === 'loading') {
        // DOM is still loading
    } else {
        // DOM is already loaded
        updateSpatialNavigation();
        console.log('Spatial navigation initialized. Press "' + toggleKey + '" to toggle navigation mode.');
    }
})();