document.addEventListener('DOMContentLoaded', function() {
    // --- State Management ---
    var state = {
        currentValue: '0',
        previousValue: null,
        operator: null, // '+', '-', '*', '/', '^'
        history: '',
        isNewInput: true,
        isMenuOpen: false,
        menuIndex: 4 // Start at center
    };

    var SCI_FUNCS = [
        { label: 'sin', desc: 'Sine' },
        { label: 'cos', desc: 'Cosine' },
        { label: 'tan', desc: 'Tangent' },
        { label: '√', desc: 'Sqrt' },
        { label: '^', desc: 'Power' },
        { label: 'log', desc: 'Log10' },
        { label: 'ln', desc: 'Ln' },
        { label: 'π', desc: 'Pi' },
        { label: 'e', desc: 'Euler' }
    ];

    // --- DOM Elements ---
    var elDisplay = document.getElementById('display');
    var elHistory = document.getElementById('history');
    var elMenuOverlay = document.getElementById('menu-overlay');
    var elMenuGrid = document.getElementById('menu-grid');
    var elSkLeft = document.getElementById('sk-left');
    var elSkCenter = document.getElementById('sk-center');
    var elSkRight = document.getElementById('sk-right');
    
    // Guide Elements
    var guides = {
        '+': document.getElementById('guide-up'),
        '-': document.getElementById('guide-down'),
        '/': document.getElementById('guide-left'),
        '*': document.getElementById('guide-right')
    };

    // --- Initialization ---
    renderMenu();
    updateDisplay();

    // --- Core Logic ---

    function calculate(a, b, op) {
        var num1 = parseFloat(a);
        var num2 = parseFloat(b);

        if (isNaN(num1) || isNaN(num2)) return '0';

        var result = 0;
        switch (op) {
            case '+': result = num1 + num2; break;
            case '-': result = num1 - num2; break;
            case '*': result = num1 * num2; break;
            case '/': result = num2 !== 0 ? num1 / num2 : 0; break;
            case '^': result = Math.pow(num1, num2); break;
        }

        // Rounding to 8 decimals
        return String(Math.round(result * 100000000) / 100000000);
    }

    function handleNumberInput(num) {
        if (state.currentValue.length > 10 && !state.isNewInput) return;

        if (state.isNewInput || state.currentValue === '0') {
            state.currentValue = num;
        } else {
            state.currentValue += num;
        }
        state.isNewInput = false;
        updateDisplay();
    }

    function handleOperatorInput(newOp) {
        if (state.operator && !state.isNewInput && state.previousValue) {
            var result = calculate(state.previousValue, state.currentValue, state.operator);
            state.currentValue = result;
            state.previousValue = result;
            state.history = result + ' ' + newOp;
        } else {
            state.previousValue = state.currentValue;
            state.history = state.currentValue + ' ' + newOp;
        }
        state.operator = newOp;
        state.isNewInput = true;
        updateDisplay();
    }

    function handleScientificFunction(index) {
        var funcObj = SCI_FUNCS[index];
        var funcName = funcObj.label;
        var val = parseFloat(state.currentValue);
        var res = 0;

        if (funcName === 'π') {
            state.currentValue = String(Math.PI);
            state.isNewInput = true;
            updateDisplay();
            return;
        }
        if (funcName === 'e') {
            state.currentValue = String(Math.E);
            state.isNewInput = true;
            updateDisplay();
            return;
        }
        if (funcName === '^') {
            handleOperatorInput('^');
            return;
        }

        switch (funcName) {
            case 'sin': res = Math.sin(val * (Math.PI / 180)); break;
            case 'cos': res = Math.cos(val * (Math.PI / 180)); break;
            case 'tan': res = Math.tan(val * (Math.PI / 180)); break;
            case '√': res = Math.sqrt(val); break;
            case 'log': res = Math.log10(val); break;
            case 'ln': res = Math.log(val); break;
        }

        state.currentValue = String(Math.round(res * 100000000) / 100000000);
        state.history = funcName + '(' + val + ')';
        state.isNewInput = true;
        updateDisplay();
    }

    function handleEquals() {
        if (state.operator && state.previousValue) {
            var result = calculate(state.previousValue, state.currentValue, state.operator);
            state.history = state.previousValue + ' ' + state.operator + ' ' + state.currentValue + ' =';
            state.currentValue = result;
            state.previousValue = null;
            state.operator = null;
            state.isNewInput = true;
            updateDisplay();
        }
    }

    function handleClear() {
        state.currentValue = '0';
        state.previousValue = null;
        state.operator = null;
        state.history = '';
        state.isNewInput = true;
        updateDisplay();
    }

    function handleDelete() {
        if (state.isNewInput) return;
        if (state.currentValue.length <= 1) {
            state.currentValue = '0';
        } else {
            state.currentValue = state.currentValue.slice(0, -1);
        }
        updateDisplay();
    }

    // --- Menu Handling ---
    function renderMenu() {
        elMenuGrid.innerHTML = '';
        SCI_FUNCS.forEach(function(fn, index) {
            var div = document.createElement('div');
            div.className = 'menu-item' + (index === state.menuIndex ? ' selected' : '');
            
            var label = document.createElement('span');
            label.className = 'menu-label';
            label.textContent = fn.label;
            
            var desc = document.createElement('span');
            desc.className = 'menu-desc';
            desc.textContent = fn.desc;

            div.appendChild(label);
            div.appendChild(desc);
            elMenuGrid.appendChild(div);
        });
    }

    function toggleMenu(show) {
        state.isMenuOpen = show;
        if (show) {
            elMenuOverlay.classList.remove('hidden');
            state.menuIndex = 4; // Reset to center
            renderMenu();
        } else {
            elMenuOverlay.classList.add('hidden');
        }
        updateDisplay(); // To update soft keys
    }

    function handleMenuNav(dir) {
        var idx = state.menuIndex;
        if (dir === 'Up') idx -= 3;
        if (dir === 'Down') idx += 3;
        if (dir === 'Left') idx -= 1;
        if (dir === 'Right') idx += 1;

        if (idx < 0) idx += 9;
        if (idx > 8) idx -= 9;

        state.menuIndex = idx;
        renderMenu();
    }

    // --- UI Update ---
    function updateDisplay() {
        elDisplay.textContent = state.currentValue;
        elHistory.textContent = state.history;

        // Update Guide Active State
        for (var op in guides) {
            if (state.operator === op) {
                guides[op].classList.add('active');
            } else {
                guides[op].classList.remove('active');
            }
        }

        // Update Soft Keys
        if (state.isMenuOpen) {
            elSkLeft.textContent = 'BACK';
            elSkCenter.textContent = 'OK';
            elSkRight.textContent = '';
        } else {
            elSkLeft.textContent = 'FUNC';
            elSkCenter.textContent = '=';
            elSkRight.textContent = (state.currentValue === '0' && state.isNewInput) ? 'AC' : 'DEL';
        }
    }

    // --- Input Handling ---
    function handleInput(key) {
        // Menu Mode
        if (state.isMenuOpen) {
            if (key === 'ArrowUp') handleMenuNav('Up');
            if (key === 'ArrowDown') handleMenuNav('Down');
            if (key === 'ArrowLeft') handleMenuNav('Left');
            if (key === 'ArrowRight') handleMenuNav('Right');
            if (key === 'Enter' || key === 'SoftRight' || key === '5') {
                handleScientificFunction(state.menuIndex);
                toggleMenu(false);
            }
            if (key === 'SoftLeft' || key === 'Backspace' || key === 'End') {
                toggleMenu(false);
            }
            return;
        }

        // Calculator Mode
        if (key >= '0' && key <= '9') {
            handleNumberInput(key);
            return;
        }
        
        switch (key) {
            case 'ArrowUp': handleOperatorInput('+'); break;
            case 'ArrowDown': handleOperatorInput('-'); break;
            case 'ArrowLeft': handleOperatorInput('/'); break;
            case 'ArrowRight': handleOperatorInput('*'); break;
            
            case 'Enter': 
            case '=':
                handleEquals(); 
                break;
            
            case 'SoftLeft': 
                toggleMenu(true); 
                break;
            
            case 'SoftRight':
                if (state.currentValue === '0' || state.isNewInput) handleClear();
                else handleDelete();
                break;
            
            case 'Backspace': 
                handleDelete(); 
                break;
            
            case 'c':
            case 'Delete':
                handleClear();
                break;
        }
    }

    // --- Event Listeners ---
    window.addEventListener('keydown', function(e) {
        var key = e.key;
        
        // Map common keys to KaiOS standards if emulating on PC
        if (key === 'F1') key = 'SoftLeft';
        if (key === 'F2') key = 'SoftRight';
        
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].indexOf(key) !== -1) {
            e.preventDefault();
        }

        handleInput(key);
    });
});